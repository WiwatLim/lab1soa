package th.ac.ku.eng.cpe.soa.lab1.model;

import java.io.FileOutputStream;
import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class BookstoreXML {

    public static void main(String[] args) {
        try {
            Document doc = DocumentFactory.getInstance().createDocument();
            Element bookstore = doc.addElement("bookstore"); 

            Element book1 = bookstore.addElement("book")
                    .addAttribute("ISBN", "0123456001");
            book1.addElement("title").addText("Java For Dummies");
            book1.addElement("author").addText("Tan Ah Teck");
            book1.addElement("category").addText("Programming");
            book1.addElement("year").addText("2009");
            book1.addElement("edition").addText("7");
            book1.addElement("price").addText("19.99");

            Element book2 = bookstore.addElement("book")
                    .addAttribute("ISBN", "0123456002");
            book2.addElement("title").addText("More Java For Dummies");
            book2.addElement("author").addText("Tan Ah Teck");
            book2.addElement("category").addText("Programming");
            book2.addElement("year").addText("2008");
            book2.addElement("price").addText("25.99");

            Element book3 = bookstore.addElement("book")
                    .addAttribute("ISBN", "0123456010");
            book3.addElement("title").addText("The Complete Guide to Fishing");
            book3.addElement("author").addText("Bill Jones");
            book3.addElement("author").addText("James Cook");
            book3.addElement("author").addText("Mary Turing");
            book3.addElement("category").addText("Fishing");
            book3.addElement("category").addText("Leisure");
            book3.addElement("language").addText("French");
            book3.addElement("year").addText("2000");
            book3.addElement("edition").addText("2");
            book3.addElement("price").addText("49.99");

            FileOutputStream fos = new FileOutputStream("bookstoreXML.xml");
            OutputFormat format = OutputFormat.createPrettyPrint();
            XMLWriter writer = new XMLWriter(fos, format);
            writer.write(doc);
            writer.flush();
            writer.close();
            fos.close();

            System.out.println("XML created successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
