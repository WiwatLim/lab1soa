package th.ac.ku.eng.cpe.soa.lab1.model;

import java.io.FileOutputStream;
import th.ac.ku.eng.cpe.soa.lab1.model.BookStore;
import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class main {

	public static void main(String[] args) throws Exception{
		BookStore b = new BookStore() ;
		b.setIsbn("0123456001");
		b.setTitle("Java For Dummies");
		b.setAuthor("Tan Ah Teck");
		b.setCategory("Programming");
		b.setYear(2009);
		b.setEdition((byte)7);
		b.setPrice(19.99);
		
		Document doc = DocumentFactory.getInstance().createDocument();
        Element root = doc.addElement("bookstore"); // Root element

        Element book = root.addElement("book").addAttribute("ISBN", b.getIsbn());
        book.addElement("title").addText(b.getTitle());
        book.addElement("author").addText(b.getAuthor());
        book.addElement("category").addText(b.getCategory());
        book.addElement("year").addText(String.valueOf(b.getYear()));
        book.addElement("edition").addText(String.valueOf(b.getEdition()));
        book.addElement("price").addText(String.valueOf(b.getPrice()));
		
		FileOutputStream fos = new FileOutputStream("bookstore.xml");
		OutputFormat format = OutputFormat.createPrettyPrint();
		XMLWriter writer = new XMLWriter(fos,format);
		writer.write(doc);
		writer.flush();
		writer.close();
		fos.close();
	}
	
	
}
